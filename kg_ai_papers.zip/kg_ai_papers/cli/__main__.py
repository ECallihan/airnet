# kg_ai_papers/cli/__main__.py

from . import main

if __name__ == "__main__":
    main()
