# kg_ai_papers/models/__init__.py

"""
Convenience re-exports for core model types.

Tests and callers often import `Paper` from `kg_ai_papers.models`, so we
expose it here, along with other commonly used model classes.
"""

from .paper import Paper
from .reference import Reference
from .section import Section
from .concept import ConceptOccurrence

__all__ = [
    "Paper",
    "Reference",
    "Section",
    "ConceptOccurrence",
]
